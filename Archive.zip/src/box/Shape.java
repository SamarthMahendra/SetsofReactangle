package box;

public interface Shape {
    // Method to calculate area
    double getArea();
}
